/*
 * @author <a href="mailto:novotny@aei.mpg.de">Jason Novotny</a>
 * @version $Id: PortletService.java 1695 2003-05-27 14:32:03Z novotny $
 */
package org.gridlab.gridsphere.portlet.service;

/**
 * The <code>PortletService</code> interface is the base for all portlet services.
 * Portlets can obtain portlet service instances by calling the method PortletContext.getService.
 */
public interface PortletService {

}
