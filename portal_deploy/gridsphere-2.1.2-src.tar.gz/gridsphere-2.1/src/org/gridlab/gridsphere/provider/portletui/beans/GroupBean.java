package org.gridlab.gridsphere.provider.portletui.beans;

/**
 * The <code>GroupBean</code> provides a way to visually group elements with an optional label.
 */
public class GroupBean extends BeanContainer implements TagBean {

    private String label = null;
    private String height = null;
    private String width = null;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }


    public String toStartString() {

        if (width != null) this.addCssStyle(" width=\"" + width + "\" ");
        if (height != null) this.addCssStyle(" height=\"" + height + "\" ");

        StringBuffer sb = new StringBuffer();
        sb.append("<fieldset" + getFormattedCss() + ">");
        if (this.label != null) {
            sb.append("<legend>" + label + "</legend>");
        }
        return sb.toString();
    }

    public String toEndString() {
        return "</fieldset>";
    }

}
