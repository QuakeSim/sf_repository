/*
 * @author <a href="mailto:novotny@aei.mpg.de">Jason Novotny</a>
 * @version $Id: ComponentAction.java 3298 2004-06-29 14:19:44Z wehrens $
 */
package org.gridlab.gridsphere.layout.event;


/**
 * A <code>ComponentAction</code> identifies any kind of portlet component action by integer
 */
public interface ComponentAction {

    public int getID();

}
