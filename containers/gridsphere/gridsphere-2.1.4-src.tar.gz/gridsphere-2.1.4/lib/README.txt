$Id: README.txt 4262 2005-09-16 10:20:27Z novotny $

This directory contains all the third-party libraries required for the compilation/deployment of GridSphere. All licenses are open source and cann be found in the licenses directory.





